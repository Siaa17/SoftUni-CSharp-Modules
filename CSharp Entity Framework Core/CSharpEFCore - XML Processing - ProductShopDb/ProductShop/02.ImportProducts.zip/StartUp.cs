﻿using System;
using System.IO;
using System.Linq;
using System.Xml.Serialization;
using ProductShop.Data;
using ProductShop.Models;
using ProductShop.Dtos.Import;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            ProductShopContext context = new ProductShopContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            string userXml = File.ReadAllText("Datasets/users.xml");
            ImportUsers(context, userXml);

            string productXml = File.ReadAllText("Datasets/products.xml");
            string result = ImportProducts(context, productXml);
            Console.WriteLine(result);
        }

        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            XmlRootAttribute xlmRoot = new XmlRootAttribute("Users");

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ImportUserDto[]), xlmRoot);

            StringReader reader = new StringReader(inputXml);

            ImportUserDto[] dtoUsers = (ImportUserDto[])xmlSerializer.Deserialize(reader);

            User[] users = dtoUsers
                .Select(x => new User
                {
                    FirstName = x.FirstName,
                    LastName = x.LastName,
                    Age = x.Age
                })
                .ToArray();

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count()}";
        }

        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            XmlRootAttribute xlmRoot = new XmlRootAttribute("Products");

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ImportProductDto[]), xlmRoot);

            StringReader reader = new StringReader(inputXml);

            ImportProductDto[] dtoProducts = (ImportProductDto[])xmlSerializer.Deserialize(reader);

            Product[] products = dtoProducts
                .Select(x => new Product
                {
                    Name = x.Name,
                    Price = x.Price,
                    SellerId = x.SellerId,
                    BuyerId = x.BuyerId
                })
                .ToArray();

            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Count()}";
        }
    }
}