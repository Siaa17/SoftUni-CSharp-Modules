﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-7CHCGN7\SQLEXPRESS;Database=BookShop;Trusted_Connection=True";
    }
}