﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=DESKTOP-7CHCGN7\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}