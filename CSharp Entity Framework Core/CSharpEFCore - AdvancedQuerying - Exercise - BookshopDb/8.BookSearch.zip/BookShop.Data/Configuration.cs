﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => @"Server=DESKTOP-7CHCGN7\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
