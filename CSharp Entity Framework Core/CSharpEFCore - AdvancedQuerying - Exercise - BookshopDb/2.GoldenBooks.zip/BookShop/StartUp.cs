﻿namespace BookShop
{
    using System;
    using Data;
    using Initializer;
    using System.Linq;
    using System.Collections.Generic;
    using System.Text;
    using BookShop.Models.Enums;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);

            //string inputCmd = Console.ReadLine();
            //string result = GetBooksByAgeRestriction(db, inputCmd);
            string result = GetGoldenBooks(db);
            Console.WriteLine(result);
        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            StringBuilder sb = new StringBuilder();

            AgeRestriction ageRestriction = Enum.Parse<AgeRestriction>(command, true);

            List<string> bookTitles = context.Books
                .ToList()
                .Where(b => b.AgeRestriction == ageRestriction)
                .OrderBy(b => b.Title)
                .Select(b => b.Title)
                .ToList();

            foreach (string bookTitle in bookTitles)
            {
                sb.AppendLine(bookTitle);
            }

            return sb.ToString().TrimEnd();
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();

            EditionType editionType = Enum.Parse<EditionType>("Gold");

            List<string> goldenBooks = context.Books
                .Where(gb => gb.Copies < 5000 &&
                gb.EditionType == editionType)
                .OrderBy(gb => gb.BookId)
                .Select(gb => gb.Title)
                .ToList();

            foreach (string goldenBook in goldenBooks)
            {
                sb.AppendLine(goldenBook);
            }

            return sb.ToString().TrimEnd();
        }
    }
}
