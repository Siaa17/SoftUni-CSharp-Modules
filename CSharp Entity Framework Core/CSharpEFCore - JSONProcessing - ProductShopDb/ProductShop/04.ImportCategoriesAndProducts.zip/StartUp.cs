﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.ImportDtos;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        static IMapper mapper;

        public static void Main(string[] args)
        {
            ProductShopContext context = new ProductShopContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
            
            string usersJson = File.ReadAllText("../../../Datasets/users.json");
            ImportUsers(context, usersJson);

            string productsJson = File.ReadAllText("../../../Datasets/products.json");
            ImportProducts(context, productsJson);

            string categoriesJson = File.ReadAllText("../../../Datasets/categories.json");
            ImportCategories(context, categoriesJson);

            string categoryProductsJson = File.ReadAllText("../../../Datasets/categories-products.json");
            string result = ImportCategoryProducts(context, categoryProductsJson);
            Console.WriteLine(result);
        }


        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            InitializeAutoMapper();

            ICollection<ImportUserDto> dtoUsers = JsonConvert.DeserializeObject<ICollection<ImportUserDto>>(inputJson);

            ICollection<User> users = mapper.Map<ICollection<User>>(dtoUsers);

            context.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count}"; 
        }

        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            InitializeAutoMapper();

            ICollection<ImportProductDto> dtoProducts = JsonConvert.DeserializeObject<ICollection<ImportProductDto>>(inputJson);

            ICollection<Product> products = mapper.Map<ICollection<Product>>(dtoProducts);

            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Count}"; 
        }

        public static string ImportCategories(ProductShopContext context, string inputJson)
        {
            InitializeAutoMapper();

            ICollection<ImportCategoryDto> dtoCategories = JsonConvert
                .DeserializeObject<ICollection<ImportCategoryDto>>(inputJson)
                .Where(x => x.Name != null)
                .ToList();

            ICollection<Category> categories = mapper.Map<ICollection<Category>>(dtoCategories);

            context.Categories.AddRange(categories);
            context.SaveChanges();

            return $"Successfully imported {categories.Count}";
        }

        public static string ImportCategoryProducts(ProductShopContext context,string inputJson)
        {
            InitializeAutoMapper();

            ICollection<ImportCategoryProductDto> dtoCategoryProducts = JsonConvert.DeserializeObject<ICollection<ImportCategoryProductDto>>(inputJson);

            ICollection<CategoryProduct> categoryProducts = mapper.Map<ICollection<CategoryProduct>>(dtoCategoryProducts);

            context.CategoryProducts.AddRange(categoryProducts);
            context.SaveChanges();

            return $"Successfully imported {categoryProducts.Count}"; 
        }

        private static void InitializeAutoMapper()
        {
            MapperConfiguration config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<ProductShopProfile>();
            });

            mapper = config.CreateMapper();
        }
    }
}