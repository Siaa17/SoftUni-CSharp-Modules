﻿using System.Collections.Generic;

namespace CarDealer.DTO.ImportDtos
{
    public class ImportCarDto
    {
        public string Make { get; set; }

        public string Model { get; set; }

        public int TravelledDistance { get; set; }

        public ICollection<int> PartsId { get; set; }
    }
}
