﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO.ImportDtos;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        static IMapper mapper;

        public static void Main(string[] args)
        {
            CarDealerContext context = new CarDealerContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            string suppliersJson = File.ReadAllText("../../../Datasets/suppliers.json");
            ImportSuppliers(context, suppliersJson);

            string partsJson = File.ReadAllText("../../../Datasets/parts.json");
            string result = ImportParts(context, partsJson);
            Console.WriteLine(result);
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            InitializeAutoMapper();

            ICollection<ImportSupplierDto> dtoSuppliers = JsonConvert.DeserializeObject<ICollection<ImportSupplierDto>>(inputJson);

            ICollection<Supplier> suppliers = mapper.Map<ICollection<Supplier>>(dtoSuppliers);

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}.";
        }

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            InitializeAutoMapper();

            ICollection<ImportPartDto> dtoParts = JsonConvert.DeserializeObject<ICollection<ImportPartDto>>(inputJson)
                .Where(p => context.Suppliers.Select(x => x.Id).Contains(p.SupplierId))
                .ToList();

            ICollection<Part> parts = mapper.Map<ICollection<Part>>(dtoParts);

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count}."; 
        }

        private static void InitializeAutoMapper()
        {
            MapperConfiguration config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<CarDealerProfile>();
            });

            mapper = config.CreateMapper();
        }
    }
}