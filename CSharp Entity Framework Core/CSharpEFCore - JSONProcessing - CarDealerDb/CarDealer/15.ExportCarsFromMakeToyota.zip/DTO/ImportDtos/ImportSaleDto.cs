﻿namespace CarDealer.DTO.ImportDtos
{
    public class ImportSaleDto
    {
        public int CarId { get; set; }

        public int CustomerId { get; set; }

        public decimal Discount { get; set; }
    }
}
