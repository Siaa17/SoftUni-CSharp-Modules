﻿using System;
using System.IO;
using System.Linq;
using System.Xml.Serialization;
using CarDealer.Data;
using CarDealer.DTO.ImportDtos;
using CarDealer.Models;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            CarDealerContext context = new CarDealerContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            string supplierXml = File.ReadAllText("Datasets/suppliers.xml");
            ImportSuppliers(context, supplierXml);

            string partXml = File.ReadAllText("Datasets/parts.xml");
            string result = ImportParts(context, partXml);
            Console.WriteLine(result);
        }

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            XmlRootAttribute xlmRoot = new XmlRootAttribute("Suppliers");

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ImportSupplierDto[]), xlmRoot);

            StringReader reader = new StringReader(inputXml);

            ImportSupplierDto[] dtoSupliers = (ImportSupplierDto[])xmlSerializer.Deserialize(reader);

            Supplier[] suppliers = dtoSupliers
                .Select(x => new Supplier
                {
                    Name = x.Name,
                    IsImporter = x.IsImporter
                })
                .ToArray(); 

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count()}";
        }

        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            XmlRootAttribute xlmRoot = new XmlRootAttribute("Parts");

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ImportPartDto[]), xlmRoot);

            StringReader reader = new StringReader(inputXml);

            ImportPartDto[] dtoParts = (ImportPartDto[])xmlSerializer.Deserialize(reader);

            Part[] parts = dtoParts
               .Where(s => context.Suppliers.Select(x => x.Id).Contains(s.SupplierId))
               .Select(x => new Part
               {
                   Name = x.Name,
                   Price = x.Price,
                   Quantity = x.Quantity,
                   SupplierId = x.SupplierId
               })               
               .ToArray();

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count()}";
        }
    }
}